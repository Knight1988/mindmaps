var MindMapDocument = (function () {
    function MindMapDocument() {
    }
    return MindMapDocument;
}());
var MindMapCategory = (function () {
    function MindMapCategory() {
    }
    return MindMapCategory;
}());
//# sourceMappingURL=MindMapDocument.js.map