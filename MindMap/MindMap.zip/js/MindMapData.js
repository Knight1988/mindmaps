var MindMapData = (function () {
    function MindMapData() {
    }
    return MindMapData;
}());
var MindMapCategory = (function () {
    function MindMapCategory() {
    }
    return MindMapCategory;
}());
var MindMapResult = (function () {
    function MindMapResult() {
    }
    return MindMapResult;
}());
//# sourceMappingURL=MindMapData.js.map